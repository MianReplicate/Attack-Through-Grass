package net.minecraft.world.entity.boss.enderdragon.phases;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public interface DragonPhaseInstance {
	boolean isSitting();

	/**
	 * Generates particle effects appropriate to the phase (or sometimes sounds).
	 * Called by dragon's onLivingUpdate. Only used when worldObj.isRemote.
	 */
	void doClientTick();

	void doServerTick(ServerLevel level);

	void onCrystalDestroyed(EndCrystal crystal, BlockPos pos, DamageSource damageSource, @Nullable Player player);

	/**
	 * Called when this phase is set to active
	 */
	void begin();

	void end();

	/**
	 * Returns the maximum amount dragon may rise or fall during this phase
	 */
	float getFlySpeed();

	float getTurnSpeed();

	EnderDragonPhase<? extends DragonPhaseInstance> getPhase();

	/**
	 * Returns the location the dragon is flying toward
	 */
	@Nullable
	Vec3 getFlyTargetLocation();

	float onHurt(DamageSource damageSource, float amount);
}
