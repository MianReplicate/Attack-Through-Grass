package net.minecraft.world.entity.monster;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.jetbrains.annotations.Nullable;

public interface CrossbowAttackMob extends RangedAttackMob {
	void setChargingCrossbow(boolean chargingCrossbow);

	/**
	 * Gets the active target the Task system uses for tracking
	 */
	@Nullable
	LivingEntity getTarget();

	void onCrossbowAttackPerformed();

	default void performCrossbowAttack(LivingEntity user, float velocity) {
		InteractionHand interactionHand = ProjectileUtil.getWeaponHoldingHand(user, Items.CROSSBOW);
		ItemStack itemStack = user.getItemInHand(interactionHand);
		if (itemStack.getItem() instanceof CrossbowItem crossbowItem) {
			crossbowItem.performShooting(user.level(), user, interactionHand, itemStack, velocity, 14 - user.level().getDifficulty().getId() * 4, this.getTarget());
		}

		this.onCrossbowAttackPerformed();
	}
}
