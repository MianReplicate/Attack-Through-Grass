package net.minecraft.world.entity.animal.horse;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityAttachment;
import net.minecraft.world.entity.EntityAttachments;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SlotAccess;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

public abstract class AbstractChestedHorse extends AbstractHorse {
	private static final EntityDataAccessor<Boolean> DATA_ID_CHEST = SynchedEntityData.defineId(AbstractChestedHorse.class, EntityDataSerializers.BOOLEAN);
	private final EntityDimensions babyDimensions;

	protected AbstractChestedHorse(EntityType<? extends AbstractChestedHorse> entityType, Level level) {
		super(entityType, level);
		this.canGallop = false;
		this.babyDimensions = entityType.getDimensions()
			.withAttachments(EntityAttachments.builder().attach(EntityAttachment.PASSENGER, 0.0F, entityType.getHeight() - 0.15625F, 0.0F))
			.scale(0.5F);
	}

	@Override
	protected void randomizeAttributes(RandomSource random) {
		this.getAttribute(Attributes.MAX_HEALTH).setBaseValue(generateMaxHealth(random::nextInt));
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_ID_CHEST, false);
	}

	public static AttributeSupplier.Builder createBaseChestedHorseAttributes() {
		return createBaseHorseAttributes().add(Attributes.MOVEMENT_SPEED, 0.175F).add(Attributes.JUMP_STRENGTH, 0.5);
	}

	public boolean hasChest() {
		return this.entityData.get(DATA_ID_CHEST);
	}

	public void setChest(boolean chested) {
		this.entityData.set(DATA_ID_CHEST, chested);
	}

	@Override
	public EntityDimensions getDefaultDimensions(Pose pose) {
		return this.isBaby() ? this.babyDimensions : super.getDefaultDimensions(pose);
	}

	@Override
	protected void dropEquipment(ServerLevel level) {
		super.dropEquipment(level);
		if (this.hasChest()) {
			this.spawnAtLocation(level, Blocks.CHEST);
			this.setChest(false);
		}
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		super.addAdditionalSaveData(tag);
		tag.putBoolean("ChestedHorse", this.hasChest());
		if (this.hasChest()) {
			ListTag listTag = new ListTag();

			for (int i = 1; i < this.inventory.getContainerSize(); i++) {
				ItemStack itemStack = this.inventory.getItem(i);
				if (!itemStack.isEmpty()) {
					CompoundTag compoundTag = new CompoundTag();
					compoundTag.putByte("Slot", (byte)(i - 1));
					listTag.add(itemStack.save(this.registryAccess(), compoundTag));
				}
			}

			tag.put("Items", listTag);
		}
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		super.readAdditionalSaveData(tag);
		this.setChest(tag.getBoolean("ChestedHorse"));
		this.createInventory();
		if (this.hasChest()) {
			ListTag listTag = tag.getList("Items", 10);

			for (int i = 0; i < listTag.size(); i++) {
				CompoundTag compoundTag = listTag.getCompound(i);
				int j = compoundTag.getByte("Slot") & 255;
				if (j < this.inventory.getContainerSize() - 1) {
					this.inventory.setItem(j + 1, (ItemStack)ItemStack.parse(this.registryAccess(), compoundTag).orElse(ItemStack.EMPTY));
				}
			}
		}

		this.syncSaddleToClients();
	}

	@Override
	public SlotAccess getSlot(int slot) {
		return slot == 499 ? new SlotAccess() {
			@Override
			public ItemStack get() {
				return AbstractChestedHorse.this.hasChest() ? new ItemStack(Items.CHEST) : ItemStack.EMPTY;
			}

			@Override
			public boolean set(ItemStack carried) {
				if (carried.isEmpty()) {
					if (AbstractChestedHorse.this.hasChest()) {
						AbstractChestedHorse.this.setChest(false);
						AbstractChestedHorse.this.createInventory();
					}

					return true;
				} else if (carried.is(Items.CHEST)) {
					if (!AbstractChestedHorse.this.hasChest()) {
						AbstractChestedHorse.this.setChest(true);
						AbstractChestedHorse.this.createInventory();
					}

					return true;
				} else {
					return false;
				}
			}
		} : super.getSlot(slot);
	}

	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		boolean bl = !this.isBaby() && this.isTamed() && player.isSecondaryUseActive();
		if (!this.isVehicle() && !bl) {
			ItemStack itemStack = player.getItemInHand(hand);
			if (!itemStack.isEmpty()) {
				if (this.isFood(itemStack)) {
					return this.fedFood(player, itemStack);
				}

				if (!this.isTamed()) {
					this.makeMad();
					return InteractionResult.SUCCESS;
				}

				if (!this.hasChest() && itemStack.is(Items.CHEST)) {
					this.equipChest(player, itemStack);
					return InteractionResult.SUCCESS;
				}
			}

			return super.mobInteract(player, hand);
		} else {
			return super.mobInteract(player, hand);
		}
	}

	private void equipChest(Player player, ItemStack chestStack) {
		this.setChest(true);
		this.playChestEquipsSound();
		chestStack.consume(1, player);
		this.createInventory();
	}

	protected void playChestEquipsSound() {
		this.playSound(SoundEvents.DONKEY_CHEST, 1.0F, (this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
	}

	@Override
	public int getInventoryColumns() {
		return this.hasChest() ? 5 : 0;
	}
}
