package net.minecraft.world.entity.decoration;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.Holder;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundAddEntityPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.PaintingVariantTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.VariantHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class Painting extends HangingEntity implements VariantHolder<Holder<PaintingVariant>> {
	private static final EntityDataAccessor<Holder<PaintingVariant>> DATA_PAINTING_VARIANT_ID = SynchedEntityData.defineId(
		Painting.class, EntityDataSerializers.PAINTING_VARIANT
	);
	public static final MapCodec<Holder<PaintingVariant>> VARIANT_MAP_CODEC = PaintingVariant.CODEC.fieldOf("variant");
	public static final Codec<Holder<PaintingVariant>> VARIANT_CODEC = VARIANT_MAP_CODEC.codec();
	public static final float DEPTH = 0.0625F;

	public Painting(EntityType<? extends Painting> entityType, Level level) {
		super(entityType, level);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		builder.define(DATA_PAINTING_VARIANT_ID, (Holder<PaintingVariant>)this.registryAccess().lookupOrThrow(Registries.PAINTING_VARIANT).getAny().orElseThrow());
	}

	@Override
	public void onSyncedDataUpdated(EntityDataAccessor<?> dataAccessor) {
		if (DATA_PAINTING_VARIANT_ID.equals(dataAccessor)) {
			this.recalculateBoundingBox();
		}
	}

	public void setVariant(Holder<PaintingVariant> variant) {
		this.entityData.set(DATA_PAINTING_VARIANT_ID, variant);
	}

	public Holder<PaintingVariant> getVariant() {
		return this.entityData.get(DATA_PAINTING_VARIANT_ID);
	}

	public static Optional<Painting> create(Level level, BlockPos pos, Direction direction) {
		Painting painting = new Painting(level, pos);
		List<Holder<PaintingVariant>> list = new ArrayList();
		level.registryAccess().lookupOrThrow(Registries.PAINTING_VARIANT).getTagOrEmpty(PaintingVariantTags.PLACEABLE).forEach(list::add);
		if (list.isEmpty()) {
			return Optional.empty();
		} else {
			painting.setDirection(direction);
			list.removeIf(holder -> {
				painting.setVariant(holder);
				return !painting.survives();
			});
			if (list.isEmpty()) {
				return Optional.empty();
			} else {
				int i = list.stream().mapToInt(Painting::variantArea).max().orElse(0);
				list.removeIf(holder -> variantArea(holder) < i);
				Optional<Holder<PaintingVariant>> optional = Util.getRandomSafe(list, painting.random);
				if (optional.isEmpty()) {
					return Optional.empty();
				} else {
					painting.setVariant((Holder<PaintingVariant>)optional.get());
					painting.setDirection(direction);
					return Optional.of(painting);
				}
			}
		}
	}

	private static int variantArea(Holder<PaintingVariant> variant) {
		return variant.value().area();
	}

	private Painting(Level level, BlockPos pos) {
		super(EntityType.PAINTING, level, pos);
	}

	public Painting(Level level, BlockPos pos, Direction direction, Holder<PaintingVariant> variant) {
		this(level, pos);
		this.setVariant(variant);
		this.setDirection(direction);
	}

	@Override
	public void addAdditionalSaveData(CompoundTag tag) {
		VARIANT_CODEC.encodeStart(this.registryAccess().createSerializationContext(NbtOps.INSTANCE), this.getVariant())
			.ifSuccess(tagx -> tag.merge((CompoundTag)tagx));
		tag.putByte("facing", (byte)this.direction.get2DDataValue());
		super.addAdditionalSaveData(tag);
	}

	@Override
	public void readAdditionalSaveData(CompoundTag tag) {
		VARIANT_CODEC.parse(this.registryAccess().createSerializationContext(NbtOps.INSTANCE), tag).ifSuccess(this::setVariant);
		this.direction = Direction.from2DDataValue(tag.getByte("facing"));
		super.readAdditionalSaveData(tag);
		this.setDirection(this.direction);
	}

	@Override
	protected AABB calculateBoundingBox(BlockPos pos, Direction direction) {
		float f = 0.46875F;
		Vec3 vec3 = Vec3.atCenterOf(pos).relative(direction, -0.46875);
		PaintingVariant paintingVariant = this.getVariant().value();
		double d = this.offsetForPaintingSize(paintingVariant.width());
		double e = this.offsetForPaintingSize(paintingVariant.height());
		Direction direction2 = direction.getCounterClockWise();
		Vec3 vec32 = vec3.relative(direction2, d).relative(Direction.UP, e);
		Direction.Axis axis = direction.getAxis();
		double g = axis == Direction.Axis.X ? 0.0625 : paintingVariant.width();
		double h = paintingVariant.height();
		double i = axis == Direction.Axis.Z ? 0.0625 : paintingVariant.width();
		return AABB.ofSize(vec32, g, h, i);
	}

	private double offsetForPaintingSize(int size) {
		return size % 2 == 0 ? 0.5 : 0.0;
	}

	@Override
	public void dropItem(ServerLevel level, @Nullable Entity entity) {
		if (level.getGameRules().getBoolean(GameRules.RULE_DOENTITYDROPS)) {
			this.playSound(SoundEvents.PAINTING_BREAK, 1.0F, 1.0F);
			if (!(entity instanceof Player player && player.hasInfiniteMaterials())) {
				this.spawnAtLocation(level, Items.PAINTING);
			}
		}
	}

	@Override
	public void playPlacementSound() {
		this.playSound(SoundEvents.PAINTING_PLACE, 1.0F, 1.0F);
	}

	@Override
	public void moveTo(double x, double y, double z, float yRot, float xRot) {
		this.setPos(x, y, z);
	}

	@Override
	public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps) {
		this.setPos(x, y, z);
	}

	@Override
	public Vec3 trackingPosition() {
		return Vec3.atLowerCornerOf(this.pos);
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket(ServerEntity entity) {
		return new ClientboundAddEntityPacket(this, this.direction.get3DDataValue(), this.getPos());
	}

	@Override
	public void recreateFromPacket(ClientboundAddEntityPacket packet) {
		super.recreateFromPacket(packet);
		this.setDirection(Direction.from3DDataValue(packet.getData()));
	}

	@Override
	public ItemStack getPickResult() {
		return new ItemStack(Items.PAINTING);
	}
}
